import { ScrollingCarouselDirective } from './scrolling-carousel.directive';

describe('ScrollingCarouselDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollingCarouselDirective();
    expect(directive).toBeTruthy();
  });
});
