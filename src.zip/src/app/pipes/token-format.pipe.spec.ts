import { TokenFormatPipe } from './token-format.pipe';

describe('TokenFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new TokenFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
