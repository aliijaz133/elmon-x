import { Directive } from '@angular/core';

@Directive({
  selector: '[appScrollingCarousel]'
})
export class ScrollingCarouselDirective {

  constructor() { }

}
