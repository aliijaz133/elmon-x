import { Component } from '@angular/core';

@Component({
  selector: 'app-elmon-x',
  templateUrl: './elmon-x.component.html',
  styleUrls: ['./elmon-x.component.scss']
})
export class ElmonXComponent {

}
